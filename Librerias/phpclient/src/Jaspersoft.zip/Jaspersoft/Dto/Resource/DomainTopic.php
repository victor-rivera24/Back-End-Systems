<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class DomainTopic
 * @package Jaspersoft\Dto\Resource
 */
class DomainTopic extends ReportUnit
{
}