<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class BeanDataSource
 * @package Jaspersoft\Dto\Resource
 */
class BeanDataSource extends Resource
{
    public $beanName;
    public $beanMethod;
}