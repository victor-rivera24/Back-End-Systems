<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class MondrianConnection
 * @package Jaspersoft\Dto\Resource
 */
class MondrianConnection extends CompositeResource
{
    public $schema;
    public $dataSource;
}