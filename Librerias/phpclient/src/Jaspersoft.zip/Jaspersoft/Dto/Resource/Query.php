<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class Query
 * @package Jaspersoft\Dto\Resource
 */
class Query extends CompositeResource
{
    public $value;
    public $language;
    public $dataSource;
}