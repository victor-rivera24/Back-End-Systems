<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class File
 * @package Jaspersoft\Dto\Resource
 */
class File extends Resource
{
    public $content;
    public $type;
}